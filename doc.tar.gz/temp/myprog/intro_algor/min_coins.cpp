/*************************************************************************
  > File Name: min_coins.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月16日 星期六 21时11分00秒
 ************************************************************************/

#include<iostream>

void min_coins(int s,int* v,int n,int* min,int* c)
{
	for(int i=1;i<=s;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(i>=v[j])
			{
				if(min[i]>min[i-v[j]]+1)
				{
					min[i]=min[i-v[j]]+1;
					c[i]=v[j];
				}
			}
		}
	}
}

void print(int* c,int s)
{
	for(int i=s;i>0;)
	{
		//std::cout<<c[s];
		//i--;
		std::cout<<c[i]<<" ";
		i-=c[i];
	}
	std::cout<<std::endl;
}

int main()
{
	int s=15;
	int v[]={1,5,11};
	int n=sizeof(v)/sizeof(int);
	int* min=new int[s+1];
	int* c=new int[s+1];
	for(int i=1;i<s+1;i++)
	{
		min[i]=i;
		c[i]=i;
	}
	min_coins(s,v,n,min,c);
	std::cout<<min[s]<<std::endl;
	print(c,s);
	delete[]min;
	delete[]c;
	return 0;
}
