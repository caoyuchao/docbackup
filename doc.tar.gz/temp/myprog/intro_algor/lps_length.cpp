/*************************************************************************
  > File Name: lps_length.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月15日 星期五 16时44分35秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>
typedef char seq_type;
std::string p;
int** dp=nullptr;
int** s=nullptr;
int n=0;

inline int max(int a,int b)
{
	return a>b?a:b;
}

void lps_length()
{
	for(int j=0;j<n;j++)
	{
		dp[j][j]=1;
		for(int i=j-1;i>=0;i--)
		{
			if(p[i]==p[j])
			{
				dp[i][j]=dp[i+1][j-1]+2;
			}
			else
			{
				dp[i][j]=max(dp[i+1][j],dp[i][j-1]);
			}
		}
	}
}

void prepare()
{
	dp=new int*[n];
	s=new int*[n];
	for(int i=0;i<n;i++)
	{
		dp[i]=new int[n];
		s[i]=new int[n];
	}
}

void freeSth()
{
	for(int i=0;i<n;i++)
	{
		delete[]dp[i];
		delete[]s[i];
	}
	delete[]dp;
	delete[]s;
}

void output()
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			std::cout<<std::setw(4)<<dp[i][j]<<" ";
		}
		std::cout<<std::endl;
	}
}

int main(int argc,char* argv[])
{
	if(argc<2)
	{
		std::cout<<"need more arguments"<<std::endl;
		exit(0);
	}
	p=argv[1];
	n=p.size();
	prepare();
	lps_length();
	output();
	freeSth();
	return 0;
}
