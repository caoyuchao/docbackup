/*************************************************************************
  > File Name: lcs_length.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月15日 星期五 15时40分29秒
 ************************************************************************/

#include<iostream>
#include<fstream>
#include<iomanip>
typedef char seq_type;
seq_type* x;
int x_length=0;
seq_type* y;
int y_length=0;

int** b=nullptr;
int** c=nullptr;

#define UP 1
#define LEFT 2
#define LEFT_UP 3


void lcs_length()
{
	for(int i=1;i<=x_length;i++)
	{
		for(int j=1;j<=y_length;j++)
		{
			if(x[i]==y[j])
			{
				c[i][j]=c[i-1][j-1]+1;
				b[i][j]=LEFT_UP;
			}
			else if(c[i-1][j]>=c[i][j-1])
			{
				c[i][j]=c[i-1][j];
				b[i][j]=UP;
			}
			else
			{
				c[i][j]=c[i][j-1];
				b[i][j]=LEFT;
			}
		}
	}
}

void  prepareAndRead(std::ifstream& in)
{
	in>>x_length;in.get();
	x=new seq_type[x_length];
	for(int i=1;i<=x_length;i++)
	{
		in>>x[i];
	}
	in.get();
	in>>y_length;in.get();
	y=new seq_type[y_length];
	for(int i=1;i<=y_length;i++)
	{
		in>>y[i];
	}

	b=new int*[x_length+1];
	c=new int*[x_length+1];
	for(int i=0;i<x_length+1;i++)
	{
		b[i]=new int[y_length+1];
		c[i]=new int[y_length+1];
	}
}

void freeSth()
{
	delete[]x;
	delete[]y;
	for(int i=0;i<x_length+1;i++)
	{
		delete[]b[i];
		delete[]c[i];
	}
	delete[]b;
	delete[]c;
}	
void print_lcs(int i,int j)
{
	if(i==0||j==0)
		return;
	if(b[i][j]==LEFT_UP)
	{
		print_lcs(i-1,j-1);
		std::cout<<x[i];
	}
	else if(b[i][j]==UP)
	{
		print_lcs(i-1,j);
	}
	else
	{
		print_lcs(i,j-1);
	}
}

void output()
{
	for(int i=0;i<x_length+1;i++)
	{
		for(int j=0;j<y_length+1;j++)
		{
			std::cout<<std::setw(2)<<c[i][j]<<" ";
		}
		std::cout<<std::endl;
	}
	std::cout<<"1->UP 2->LEFT 3->LEFT_UP "<<std::endl;
	for(int i=0;i<x_length+1;i++)
	{
		for(int j=0;j<y_length+1;j++)
		{
			std::cout<<std::setw(2)<<b[i][j]<<" ";
		}
		std::cout<<std::endl;
	}
	print_lcs(x_length,y_length);
	std::cout<<std::endl;
}

void prinf_debug()
{
	for(int i=0;i<x_length;i++)
	{
		std::cout<<x[i]<<" ";
	}
	std::cout<<std::endl;
	for(int i=0;i<y_length;i++)
	{
		std::cout<<y[i]<<" ";
	}
	std::cout<<std::endl;
}

int main(int argc,char* argv[])
{
	std::string filename="lcs";
	if(argc>1)
		filename=argv[1];
	std::ifstream in(filename);
	if(!in)
	{
		std::cout<<"can not open file "<<filename<<std::endl;
		exit(0);
	}
	prepareAndRead(in);
	prinf_debug();
	lcs_length();
	output();
	freeSth();
	return 0;
}
