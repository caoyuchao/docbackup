/*************************************************************************
  > File Name: extended_cut_rod.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月15日 星期五 13时49分30秒
 ************************************************************************/

#include<iostream>
#include<fstream>
#include<sstream>
typedef int price_type;

price_type* p=nullptr;
price_type* r=nullptr;
int* s=nullptr;
int n=1;
int N_need=1;
const int NEG_INFINITE=-123456789;
void extended_cut_rod()
{
	r[0]=0;
	for(int j=1;j<=n;j++)
	{
		int q=NEG_INFINITE;
		for(int i=1;i<=j;i++)
		{
			if(q<p[i]+r[j-i])
			{
				q=p[i]+r[j-i];//长度为j，分为i和j-i长度
				s[j]=i;//记录两段中前一段长度
			}
		}
		r[j]=q;//更新j长度的最大效益
	}
}

void prepare()
{
	p=new price_type[n+1];
	r=new price_type[n+1];
	s=new int[n+1];
}

void readData(std::ifstream& in)
{
	for(int i=1;i<=n;i++)
	{
		in>>p[i];
	}
}

void print_rod_cut_solu(int n)
{
	std::cout<<"solu:"<<std::endl;
	while(n>0)
	{
		std::cout<<s[n]<<" ";
		n=n-s[n];
	}
	std::cout<<std::endl;
}

void output()
{
	std::cout<<N_need<<" rods max profit "<<r[N_need]<<std::endl;
	print_rod_cut_solu(N_need);
}


void freeSth()
{
	delete[]p;
	delete[]r;
	delete[]s;
}

void print_debug()
{
	for(int i=0;i<=n;i++)
	{
		std::cout<<p[i]<<" ";
	}
	std::cout<<std::endl;
	for(int i=0;i<=n;i++)
	{
		std::cout<<r[i]<<" ";
	}
	std::cout<<std::endl;
	for(int i=0;i<=n;i++)
	{
		std::cout<<s[i]<<" ";
	}
	std::cout<<std::endl;
}

int main(int argc,char* argv[])
{
	std::string filename="price";
	if(argc>1)
	{
		std::stringstream ss;
		ss<<argv[1];
		ss>>N_need;
		if(argc>2)
		{
			filename=argv[2];
		}
	}
	std::ifstream in(filename);
	if(!in)
	{
		std::cout<<"can not open "<<filename<<std::endl;
		exit(0);
	}
	in>>n;
	in.get();
	if(N_need>n)
	{
		std::cout<<"can not cut so many rods"<<std::endl;
		exit(0);
	}
	prepare();
	readData(in);
	extended_cut_rod();
	output();
	freeSth();
	return 0;
}
