/*************************************************************************
  > File Name: matrix_chain_order.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月15日 星期五 14时38分14秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<fstream>

int* p=nullptr;
int** m=nullptr;
int** s=nullptr;
int num_p=1;

const int INFINITE=123456789;

void matrix_chain_order()
{
	int n=num_p-1;
	for(int l=2;l<=n;l++)
	{
		for(int i=1;i<=n-l+1;i++)
		{
			int j=i+l-1;
			m[i][j]=INFINITE;
			for(int k=i;k<=j-1;k++)
			{
				int q=m[i][k]+m[k+1][j]+p[i-1]*p[k]*p[j];//状态转移方程
				if(q<m[i][j])
				{
					m[i][j]=q;
					s[i][j]=k;//记录括号的位置
				}
			}
		}
	}
}

void prepare()
{
	p=new int[num_p];
	m=new int*[num_p];
	s=new int*[num_p];
	for(int i=0;i<num_p;i++)
	{
		m[i]=new int[num_p];
		s[i]=new int[num_p];
	}
}

void readData(std::ifstream& in)
{
	for(int i=0;i<num_p;i++)
	{
		in>>p[i];
	}
}

void print_optimal_parens(int i,int j)
{
	if(i==j)
	{
		std::cout<<"A"<<i;
	}
	else
	{
		std::cout<<"(";
		print_optimal_parens(i,s[i][j]);
		print_optimal_parens(s[i][j]+1,j);
		std::cout<<")";
	}
}

void output()
{
	std::cout<<"m[i][j]:"<<std::endl;
	for(int i=1;i<num_p-1;i++)
	{
		for(int k=1;k<num_p-i+10;k++)
			std::cout<<"  ";
		for(int j=num_p-i;j<num_p;j++)
		{
			std::cout<<m[i+j-num_p+1][j]<<" ";
		}
		std::cout<<std::endl;
	}

	std::cout<<"s[i][j]:"<<std::endl;
	for(int i=1;i<num_p-1;i++)
	{
		for(int k=1;k<num_p-i+10;k++)
			std::cout<<"  ";
		for(int j=num_p-i;j<num_p;j++)
		{
			std::cout<<s[i+j-num_p+1][j]<<"   ";
		}
		std::cout<<std::endl;
	}
	print_optimal_parens(1,num_p-1);
	std::cout<<std::endl;
}


void freeSth()
{
	delete[]p;
	for(int i=0;i<num_p;i++)
	{
		delete[]m[i];
		delete[]s[i];
	}
	delete[]m;
	delete[]s;

}

int main(int argc,char* argv[])
{
	std::string filename="matrix_chain";
	if(argc>1)
		filename=argv[1];
	std::ifstream in(filename);
	if(!in)
	{
		std::cout<<"can not open file "<<filename<<std::endl;
		exit(0);
	}
	in>>num_p;
	in.get();
	prepare();
	readData(in);
	matrix_chain_order();
	output();
	freeSth();
	return 0;
}
