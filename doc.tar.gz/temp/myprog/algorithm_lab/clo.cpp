/*************************************************************************
  > File Name: closeMore.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月10日 星期日 12时31分38秒
 ************************************************************************/

#include<iostream>
#include<algorithm>
#include<cmath>
#include<sstream>
#include<fstream>
#include<iomanip>
#include<map>
const size_t pnum=1000;//最大点个数

struct point
{
	double x;
	double y;
};

point Points[pnum+1];//最后一个空间用作超尾，作为排序的接口
size_t pointsAcrossMidIndex[pnum+1];//存放跨越中间点（以x坐标为标准）的坐标的索引

inline double distance(const point& point1,const point& point2)//欧氏距离
{
	return std::sqrt((point1.x-point2.x)*(point1.x-point2.x)+(point1.y-point2.y)*(point1.y-point2.y));
}

void output(std::multimap<size_t,size_t>& mymap)
{
	size_t cursor=pnum+1;
	for(auto it=mymap.begin();it!=mymap.end();++it)
	{
		if(cursor==it->first)
			continue;
		auto pos=mymap.equal_range(it->first);
		while(pos.first!=pos.second)
		{
			std::cout<<Points[it->first].x<<","<<Points[it->first].y<<" "<<Points[pos.first->second].x<<","<<Points[pos.first->second].y<<std::endl;
			++pos.first;
		}
		cursor=it->first;
	}
}
double closestDis(size_t low,size_t high,std::multimap<size_t,size_t>& mymap)//求最近点对,并记录最近点对的索引
{
	if(high==low+1)
	{
		mymap.insert(std::make_pair(low,high));
		return distance(Points[low],Points[high]);//两个点的时候，直接返回两点间的欧氏距离
		
	}
	if(high==low+2)//三个点的时候，返回两两之间的欧氏距离最小值，基本情况为2个点和3个点，其他情况都分递归分解成基本情况
	{
		double closeDistance=distance(Points[low],Points[high]);
		double dis0=distance(Points[low+1],Points[high]);
		double dis1=distance(Points[low],Points[low+1]);
		if(dis0<closeDistance)
		{
			mymap.insert(std::make_pair(low+1,high));
		}
		else if(closeDistance==dis0)
		{
			mymap.insert(std::make_pair(low,high));
			mymap.insert(std::make_pair(low+1,high));
		}
		else
		{
			mymap.insert(std::make_pair(low,high));
		}
		if(dis1<closeDistance)
		{
			closeDistance=dis1;
			mymap.clear();
			mymap.insert(std::make_pair(low,low+1));
		}
		else if(dis1==closeDistance)
		{
			mymap.insert(std::make_pair(low,low+1));
		}
		return closeDistance;
	}
	size_t mid=(high+low)>>1;//取中间点（x为标准）的索引
	std::multimap<size_t,size_t> mymap_r;
	double closestDistance=closestDis(low,mid,mymap);
	double dis_r=closestDis(mid+1,high,mymap_r);
	if(dis_r<closestDistance)
	{
		mymap=mymap_r;
		closestDistance=dis_r;
	}
	else if(dis_r==closestDistance)
	{
		mymap.insert(mymap_r.begin(),mymap_r.end());
	}
	int count=0;
	for(size_t i=low;i<=high;i++)
	{
		if(Points[i].x>=Points[mid].x-closestDistance&&Points[i].x<=Points[mid].x+closestDistance)
			pointsAcrossMidIndex[count++]=i;//保存跨越中间点mid带状区域的节点索引，带状区域宽度为2*closestDistance
	}
	std::sort(pointsAcrossMidIndex,pointsAcrossMidIndex+count,[=](size_t index1,size_t index2){return Points[index1].y<Points[index2].y;});//升序排列,以y为基准
	for(size_t i=0;i<count;i++)
	{
		int j=(i+7)<count?(i+7):count;//最多只需要比之后相邻七个点（八个正方形区域，每个区域边长为closestDistancce），相邻是因为已经按y排序
		for(int k=i+1;k<j;k++)
		{
			if(Points[pointsAcrossMidIndex[k]].y-Points[pointsAcrossMidIndex[i]].y>closestDistance)
				break;//如果相邻纵坐标直接大于最短距离，直接退出循环。
			double dis_m=distance(Points[pointsAcrossMidIndex[i]],Points[pointsAcrossMidIndex[k]]);
			if(dis_m<closestDistance)
			{
				mymap.clear();
				mymap.insert(std::make_pair(pointsAcrossMidIndex[i],pointsAcrossMidIndex[k]));
				closestDistance=dis_m;
			}
			else if(dis_m==closestDistance)
			{
				size_t index1;
				size_t index2;
				if(pointsAcrossMidIndex[i]<pointsAcrossMidIndex[k])
					{index1=pointsAcrossMidIndex[i];index2=pointsAcrossMidIndex[k];}
				else
					{index1=pointsAcrossMidIndex[k];index2=pointsAcrossMidIndex[i];}
				
				bool flag=false;
				if(mymap.find(index1)!=mymap.end())
				{
					auto pos=mymap.equal_range(index1);
					while(pos.first!=pos.second){if(pos.first->second==index2){flag=true;break;}++pos.first;}
				}
				if(!flag)mymap.insert(std::make_pair(index1,index2));
			}
		}
	}
	return closestDistance;
}


int main(int argc,char* argv[])
{
	std::string filename="points";
	if(argc>1)
		filename=argv[1];//带文件名参数
	std::ifstream in(filename);
	if(!in)
	{
		std::cout<<"can not open the file..."<<filename<<std::endl;
		exit(1);
	}
	size_t count=0;
	while(in>>Points[count].x>>Points[count].y)
	{
		in.get();//读换行符
		count++;//记录读取的点的数量
	}
	if(count<2)//一个点求啥子
	{
		std::cout<<"need more points..."<<std::endl;
	}
	std::sort(Points,Points+count,[=](const point& p1,const point& p2){return p1.x<p2.x;});//以x为基准排序
	size_t index1=0;
	size_t index2=0;
	std::multimap<size_t,size_t> mymap;
	std::cout<<"closest distance : "<<closestDis(0,count-1,mymap)<<std::endl;//求最短点对的距离
	output(mymap);
	return 0;
}
