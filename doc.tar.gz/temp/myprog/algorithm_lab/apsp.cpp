/*************************************************************************
  > File Name: apsp.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月13日 星期三 19时31分36秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>
#include<sstream>
typedef int matrixtype;

size_t n=5;
matrixtype** d;
int** Pi;

matrixtype min(matrixtype x,matrixtype y)
{
	return x<y?x:y;
}

void FLOYD_WARSHALL()//书405下方
{
	for(int k=0;k<n;k++)
	{
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(d[i][j]>d[i][k]+d[k][j])//407上方
					Pi[i][j]=Pi[k][j];
				d[i][j]=min(d[i][j],d[i][k]+d[k][j]);
			}
		}
	}
}

void prepare()//申请空间
{
	d=new matrixtype*[n];
	Pi=new int*[n];
	for(int i=0;i<n;i++)
	{
		d[i]=new matrixtype[n];
		Pi[i]=new int[n];
	}
}

void preparePi()//大于12345666表示无穷大，文件里是123456789
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)//书406下方
		{
			if(i==j||d[i][j]>123456666)
				Pi[i][j]=-1;
			else
				Pi[i][j]=i;
		}
	}
}


void readData(std::ifstream& in)//读文件
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			in>>d[i][j];
		}
		in.get();
	}
}

void freeSth()//释放空间
{
	for(int i=0;i<n;i++)
	{
		delete[]d[i];
		delete[]Pi[i];
	}
	delete[]d;
	delete[]Pi;
}

void output()//输出空间
{
	std::cout<<"D:"<<std::endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			std::cout<<std::setw(4)<<d[i][j]<<" ";
		}
		std::cout<<std::endl;
	}
	std::cout<<"Pi:"<<std::endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			std::cout<<std::setw(4)<<Pi[i][j]<<" ";
		}
		std::cout<<std::endl;
	}
}

void print_all_pairs(int i,int j)//打印路径，书399页
{
	if(i==j)
		std::cout<<i;
	else if(Pi[i][j]==-1)
		std::cout<<"\nno path from "<<i<<" to "<<j<<std::endl;
	else
	{
		print_all_pairs(i,Pi[i][j]);
		std::cout<<"->"<<j;
	}
}

int main(int argc,char* argv[])
{
	std::string filename="matrix";
	if(argc>1)
	{
		filename=argv[1];
	}
	std::ifstream in(filename);
	if(!in)
	{
		std::cout<<"can not open file "<<filename<<std::endl;
		exit(0);
	}

	in>>n;
	in.get();

	prepare();
	readData(in);
	preparePi();
	FLOYD_WARSHALL();
	output();
	if(argc>3)
	{
		std::stringstream ss;
		ss<<argv[2];
		int i=1;
		ss>>i;
		ss.clear();
		ss<<argv[3];
		int j=1;
		ss>>j;
		std::cout<<std::endl;
		print_all_pairs(i,j);
		std::cout<<std::endl;
	}
	freeSth();
	return 0;
}
