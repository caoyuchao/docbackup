/*************************************************************************
  > File Name: BSTree.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月13日 星期三 09时37分20秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<fstream>
#include<float.h>
typedef int matrixType;
typedef double proType;
size_t num=10;

proType** e;
proType** w;
matrixType** root;
proType* p;
proType* q;

void OPT_BST()//书229页的算法
{
	for(int i=1;i<=num+1;i++)
	{
		e[i][i-1]=q[i-1];
		w[i][i-1]=q[i-1];
	}
	for(int l=1;l<=num;l++)
	{
		for(int i=1;i<=num-l+1;i++)
		{
			int j=i+l-1;
			e[i][j]=DBL_MAX;
			w[i][j]=w[i][j-1]+p[j]+q[j];
			for(int r=i;r<=j;r++)
			{
				proType tmp=e[i][r-1]+e[r+1][j]+w[i][j];
				if(tmp<e[i][j])
				{
					e[i][j]=tmp;
					root[i][j]=r;
				}
			}
		}
	}

}

void prepare()//申请空间
{
	e=new proType*[num+2];
	for(int i=0;i<num+2;i++)
	{
		e[i]=new proType[num+1];
	}

	w=new proType*[num+2];
	for(int i=0;i<num+2;i++)
	{
		w[i]=new proType[num+1];
	}

	root=new matrixType*[num+1];
	for(int i=0;i<num+1;i++)
	{
		root[i]=new matrixType[num+1];
	}

	p=new proType[num+1];
	q=new proType[num+1];
}

void readData(std::ifstream& in)//读数据
{
	for(int i=1;i<num+1;i++)
	{
		in>>p[i];
	}
	in.get();
	for(int i=0;i<num+1;i++)
	{
		in>>q[i];
	}
}

void output()//输出数据
{
	std::cout<<"e[i][j]:"<<std::endl;
	for(int i=1;i<=num+1;i++)
	{
		for(int k=1;k<num-i+10;k++)
			std::cout<<"  ";
		for(int j=num-i+1;j<=num;j++)
		{
			std::cout<<e[i+j-num][j]<<" ";
		}
		std::cout<<std::endl;
	}
	std::cout<<"w[i][j]:"<<std::endl;
	for(int i=1;i<num+1;i++)
	{
		for(int k=1;k<num-i+10;k++)
			std::cout<<"  ";
		for(int j=num-i+1;j<=num;j++)
		{
			std::cout<<w[i+j-num][j]<<" ";
		}
		std::cout<<std::endl;
	}
	std::cout<<"root[i][j]:"<<std::endl;
	for(int i=1;i<=num;i++)
	{
		for(int k=1;k<num-i+10;k++)
			std::cout<<"  ";
		for(int j=num-i+1;j<=num;j++)
		{
			std::cout<<root[i+j-num][j]<<"   ";
		}
		std::cout<<std::endl;
	}
}

void printTree(int i,int j,matrixType rt)//递归打印树
{
	if(rt-1<i)
	{
		std::cout<<"d"<<rt-1<<" is "<<rt<<" lchild"<<std::endl;
	}
	else
	{
		matrixType lchild=root[i][rt-1];
		std::cout<<"k"<<lchild<<" is "<<rt<<" lchild"<<std::endl;
		printTree(i,rt-1,lchild);
	}
	if(rt+1>j)
	{
		std::cout<<"d"<<j<<" is "<<rt<<" rchild"<<std::endl;
	}
	else
	{
		matrixType rchild=root[rt+1][j];
		std::cout<<"k"<<rchild<<" is "<<rt<<" rchild"<<std::endl;
		printTree(rt+1,j,rchild);
	}
}

void freeSth()//释放空间
{
	for(int i=0;i<num+2;i++)
	{
		delete[]e[i];
		delete[]w[i];
	}
	delete[]e;
	delete[]w;
	for(int i=0;i<num+1;i++)
	{
		delete[]root[i];
	}
	delete[]root;
}

int main(int argc,char* argv[])
{
	std::string filename="prob";
	if(argc>1)
	{
		filename=argv[1];
	}
	std::ifstream in(filename);
	if(!in)
	{
		std::cout<<"open file failure"<<std::endl;
		exit(0);
	}
	in>>num;
	in.get();

	prepare();
	readData(in);

	OPT_BST();
	output();
	std::cout<<"k"<<root[1][num]<<" is root"<<std::endl;
	printTree(1,num,root[1][num]);
	freeSth();
	return 0;
}

