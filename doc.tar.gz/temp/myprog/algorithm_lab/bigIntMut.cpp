/*************************************************************************
  > File Name: bigIntMut.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月10日 星期日 15时30分03秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<algorithm>
#include<sstream>
//转换函数 整形->字符串
std::string int2str(int value)
{
	std::string str;
	std::stringstream ss;
	ss<<value;
	ss>>str;
	return str;
}
//转换函数 字符串->整形
int str2int(std::string str)
{
	int value;
	std::stringstream ss;
	ss<<str;
	ss>>value;
	return value;
}
//去除前导0
void removePerZero(std::string& str)
{
	if(str.size()==0)return;
	size_t index=0;
	for(;index<str.size();index++)if(str[index]!='0')break;
	index==str.size()?str="0":str=str.substr(index);
}
//大数加法底层处理
std::string addBigInt(std::string x,std::string y)
{
	removePerZero(x);
	removePerZero(y);

	std::reverse(x.begin(),x.end());
	std::reverse(y.begin(),y.end());//反转之后自动对齐了，方便计算
	std::string addsum;

	for(int i=0,carry=0;carry||i<std::max(x.size(),y.size());i++)//进位没有结束或者加法为结束都继续循环
	{
		int cur_sum=carry;//上一次加法的进位
		if(i<x.size())cur_sum+=x[i]-'0';
		if(i<y.size())cur_sum+=y[i]-'0';
		addsum.insert(0,int2str(cur_sum%10));//仅保存本位和个位
		carry=cur_sum/10;//进位位
	}
	return addsum;
}
//大数减法底层处理
std::string subBigInt(std::string x,std::string y)
{
	removePerZero(x);
	removePerZero(y);

	size_t x_size=x.size();
	size_t y_size=y.size();
	size_t size=x_size>y_size?x_size:y_size;

	char sign;
	if(x_size>y_size)sign='+';
	else if(x_size<y_size)sign='-';
	else if(x>y)sign='+';//利用字符串比较判断正负，这里的字典序就是大小
	else if(x<y)sign='-';
	else return "0";//字符串相等差为0

	std::reverse(x.begin(),x.end());//同理反转之后减法自动对齐了
	std::reverse(y.begin(),y.end());
	int* tempSubRes=new int[size];//保存每一位差，正负都记录下来，借位最后统一补偿
	size_t cursor=0;
	for(size_t i=0;i<size;i++)
	{
		int xint=i<x_size?x[i]:'0';//超出长度部分用0填充
		int yint=i<y_size?y[i]:'0';
		sign=='+'?(tempSubRes[cursor++]=xint-yint):(tempSubRes[cursor++]=yint-xint);//始终时大数减去小数，记录下来
	}
	for(size_t i=0;i<cursor;i++)
	{
		if(tempSubRes[i]<0)
		{
			tempSubRes[i+1]-=1;//补偿借位
			tempSubRes[i]+=10;
		}
	}
	while(tempSubRes[--cursor]==0);//去除前导0
	std::string strRes;
	for(int i=cursor;i>=0;i--)
		strRes.push_back(tempSubRes[i]+'0');//构造成串
	//std::cout<<"OK"<<std::endl;
	if(sign=='-')
		strRes.insert(0,1,sign);//添加符号位
	return strRes;
}
//大数乘法预处理
bool PreProcess(std::string& x,std::string& y)
{
	bool xIsNeg=false;
	bool yIsNeg=false;
	if(x[0]=='-'){xIsNeg=true;x=x.substr(1);}//右值引用赋值
	if(y[0]=='-'){yIsNeg=true;y=y.substr(1);}

	int init_size=2;
	size_t x_size=x.size();
	size_t y_size=y.size();
	size_t size=x_size>y_size?x_size:y_size;
	while(init_size<size)init_size*=2;
	x.insert(0,init_size-x_size,'0');//扩展成递归时可以等分的长度即2^k
	y.insert(0,init_size-y_size,'0');
	
	return xIsNeg!=yIsNeg;//返回符号位
}
//大数乘法
std::string Rmultiply(std::string x,std::string y)
{	
	bool ResIsNeg=PreProcess(x,y);
	size_t size=x.size();
	std::string a1(x.substr(0,size/2));//x的高位
	std::string a0(x.substr(size/2,size));//x的低位
	std::string b1(y.substr(0,size/2));//y的高位
	std::string b0(y.substr(size/2,size));//y的低位
	std::string result;
	if(size==2)
	{
		result=int2str((str2int(a1)*10+str2int(a0))*(str2int(b1)*10+str2int(b0)));
	}
	else
	{
		std::string c2=Rmultiply(a1,b1);                     //4          //A=a1*10^(n/2)+a0;                                1
		std::string c0=Rmultiply(a0,b0);                     //6          //B=b1*10^(n/2)+a0;                                2
		std::string c1_1=addBigInt(a0,a1);                   //5          //A*B=c2*10^n+c1*10^(n/2)+c0                       3
		std::string c1_2=addBigInt(b1,b0);                   //5          //c2=a1*b1                                         4
		std::string c1_3=addBigInt(c2,c0);                   //5          //c1=a0*b1+a1*b0=(a1+a0)*(b1+b0)-(c2+c0)           5
		std::string c1_4=Rmultiply(c1_1,c1_2);               //5          //c0=a0*b0                                         6
		std::string c1=subBigInt(c1_4,c1_3);                 //5
		std::string s1=c1.insert(c1.size(),size/2,'0');      //3  
		std::string s2=c2.insert(c2.size(),size,'0');        //2
		result=addBigInt(addBigInt(s1,s2),c0);               //3
	}  
	if(ResIsNeg)result.insert(0,1,'-');//添加正负号
	return result;
}
//大数加法
td::string add(std::string x,std::string y)
{
	if(x[0]=='-'&&y[0]=='-')return "-"+addBigInt(x.substr(1),y.substr(1));//-x-y==-(x+y)
	else if(x[0]=='-')return subBigInt(y,x.substr(1));//-x+y==y-x
	else if(y[0]=='-')return subBigInt(x,y.substr(1));//x+(-y)==x-y
	else return addBigInt(x,y);//x+y
}
//大数减法
std::string sub(std::string x,std::string y)
{
	if(x[0]=='-'&&y[0]=='-')return subBigInt(y.substr(1),x.substr(1));//-x-(-y)==y-x
	else if(x[0]=='-')return "-"+addBigInt(x.substr(1),y);//-x-y==-(x+y)
	else if(y[0]=='-')return addBigInt(x,y.substr(1));//x-(-y)==x+y
	else return subBigInt(x,y);//x-y
}

int main(int argc,char* argv[])
{
	if(argc<3)
	{
		std::cout<<"need more arguments..."<<std::endl;
		exit(0);
	}
	std::string op="*";
	if(argc==4)
	{
		op=argv[3];
	}
	std::string x=argv[1];
	std::string y=argv[2];
	std::stringstream ss;
	long long int a=0;
	ss<<argv[1];ss>>a;
	long long int b=0;
	ss.clear();
	ss<<argv[2];ss>>b;
	if(x[0]=='+')x=x.substr(1);
	if(y[0]=='+')y=y.substr(1);//去除前导加号

	if(op=="+")//加法模式
	{
		std::cout<<"x+y = "<<add(x,y)<<std::endl;
		std::cout<<"a+b = "<<a+b<<std::endl;
	}
	else if(op=="-")//减法模式
	{
		std::cout<<"x-y = "<<sub(x,y)<<std::endl;
		std::cout<<"a-b = "<<a-b<<std::endl;
	}
	else//默认乘法模式
	{
		std::cout<<"x*y = "<<Rmultiply(x,y)<<std::endl;
		std::cout<<"a*b = "<<a*b<<std::endl;
	}
	return 0;
}













