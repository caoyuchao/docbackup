/*************************************************************************
  > File Name: prob1.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2018年01月06日 星期六 12时02分12秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<cstdlib>
#include<unistd.h>
#include<sys/types.h>
#include<cmath>

int main()
{
	double x0=1.5;
	double x1=std::pow(1+x0*x0,1.0/3);
	double e=0.005;
	while(std::abs(x1-x0)>e)
	{
		std::cout<<x1<<" "<<x1-x0<<std::endl;
		x0=x1;
		x1=std::pow(1+x0*x0,1.0/3);
	}
	std::cout<<x1<<" "<<x1-x0<<std::endl;
	return 0;
}
