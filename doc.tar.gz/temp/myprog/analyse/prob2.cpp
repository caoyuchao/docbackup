/*************************************************************************
  > File Name: prob2.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2018年01月06日 星期六 12时55分20秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<cstdlib>
#include<unistd.h>
#include<sys/types.h>
#include<cmath>
inline double f(double x)
{
	return std::pow(x,3)-3*x-1;
}	
int main()
{
   	double x0=1.9;
	double e=0.0005;
	double fx0=f(x0);
	double x1=2.0;
	double x2=x1-f(x1)*(x1-x0)/(f(x1)-fx0);
	while(std::abs(x2-x1)>e)
	{
		std::cout<<x2<<" "<<x2-x1<<std::endl;
		x1=x2;
		x2=x1-f(x1)*(x1-x0)/(f(x1)-fx0);
	}	
	std::cout<<x2<<" "<<x2-x1<<std::endl;
	return 0;
}
