/*************************************************************************
  > File Name: prob3.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2018年01月06日 星期六 15时11分46秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<cstdlib>
#include<unistd.h>
#include<sys/types.h>
#include<cmath>

double ep=0.0005;
void iter()
{

	std::cout<<"==========================="<<std::endl;
	double x0=0.5;
	double x1=std::exp(-x0);
	while(std::abs(x1-x0)>ep)
	{	
		std::cout<<x1<<" "<<x1-x0<<std::endl;
		x0=x1;
		x1=std::exp(-x0);
	}
	std::cout<<x1<<" "<<x1-x0<<std::endl;
	std::cout<<"=========================="<<std::endl;
}


void iterAcc()
{
	std::cout<<"==========================="<<std::endl;
	double x0=0.5;
	double _x1=std::exp(-x0);
	double x1=_x1-0.6/1.6*(_x1-x0);
	while(std::abs(x1-x0)>ep)
	{
		std::cout<<x1<<" "<<x1-x0<<std::endl;
		x0=x1;
		_x1=std::exp(-x0);
		x1=_x1-0.6/1.6*(_x1-x0);
	}
	std::cout<<x1<<" "<<x1-x0<<std::endl;
	std::cout<<"==========================="<<std::endl;
}

void Aitken()
{
	std::cout<<"==========================="<<std::endl;
	double x0=0.5;
	double x1_1=std::exp(-x0);
	double x1_2=std::exp(-x1_1);
	double x1=x1_2-(x1_2-x1_1)*(x1_2-x1_1)/(x1_2-2*x1_1+x0);
	while(std::abs(x1-x0)>ep)
	{
		std::cout<<x1<<" "<<x1-x0<<std::endl;
		x0=x1;
		x1_1=std::exp(-x0);
		x1_2=std::exp(-x1_1);
		x1=x1_2-(x1_2-x1_1)*(x1_2-x1_1)/(x1_2-2*x1_1+x0);
	}
	std::cout<<x1<<" "<<x1-x0<<std::endl;	
	std::cout<<"==========================="<<std::endl;
}

int main(int argc,char* argv[])
{
	int choice=3;
	if(argc>1)
	{
		choice=argv[1][0]-'0';
	}	
	switch(choice)
	{
		case 0:iter();break;
		case 1:iterAcc();break;
		case 2:Aitken();break;
		default:iter();iterAcc();Aitken();break;
	}
	return 0;
}
