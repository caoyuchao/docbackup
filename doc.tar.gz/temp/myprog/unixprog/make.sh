#########################################################################
# File Name: make.sh
# Author: caoyuchao
# mail: cycbhbjxd@gmail.com
# Created Time: 2018年01月08日 星期一 10时31分20秒
#########################################################################
#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
if [[ $1 == *.cpp ]];then
	g++ $1 apue.cpp -o `echo $1 | sed 's/.cpp//'`
elif [[ $1 == *.c ]];then
	g++ $1 apue.cpp -o `echo $1 | sed 's/.c//'`
else
	echo -e "check your input\a"
fi
