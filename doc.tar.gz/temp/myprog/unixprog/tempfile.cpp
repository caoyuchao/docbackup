/*************************************************************************
  > File Name: tempfile.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2018年01月08日 星期一 09时21分05秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<cstdlib>
#include<unistd.h>
#include<sys/types.h>
#include"apue.h"
int log_to_stderr=1;
int main()
{
	char name[L_tmpnam],line[MAXLINE];
	FILE* fp;
	printf("%s\n",tmpnam(NULL));

	tmpnam(name);
	printf("%s\n",name);

	if((fp=tmpfile())==NULL)
		err_sys("tmpfile error");
	fputs("one line of output\n",fp);
	rewind(fp);
	if(fgets(line,sizeof(line),fp)==NULL)
		err_sys("fgets error");
	fputs(line,stdout);

	return 0;
}
