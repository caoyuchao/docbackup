/*************************************************************************
  > File Name: getc.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2018年01月06日 星期六 16时58分12秒
 ************************************************************************/

#include<iostream>
#include"apue.h"
int log_to_stderr=1;
int main()
{
	int c;
	while((c=getc(stdin))!=EOF)
		if(putc(c,stdout)==EOF)
			err_sys("output error");
	if(ferror(stdin))
		err_sys("input error");

	return 0;
}
