/*************************************************************************
  > File Name: file_descriptor.c
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月15日 星期五 18时59分53秒
 ************************************************************************/

#include"apue.h"
#include<fcntl.h>
int log_to_stderr=1;
int main(int argc,char* argv[])
{
	int val;
	if(argc!=2)
		err_quit("usage: file_descriptor <descriptor#>");
	if((val=fcntl(atoi(argv[1]),F_GETFL,0))<0)
		err_sys("fcntl error for fd %d",atoi(argv[1]));

	switch(val&O_ACCMODE)
	{
		case O_RDONLY:
			printf("read only");
			break;
		case O_WRONLY:
			printf("write only");
			break;
		case O_RDWR:
			printf("write read");
			break;
		default:
			err_dump("unknown access mode");
	}

	if(val&O_APPEND)
		printf(",append");
	if(val&O_NONBLOCK)
		printf(",nonblocking");
	if(val&O_SYNC)
		printf(",synchronous writes");

#if !defined(_POSIX_C_SOURCE)&&defined(O_FSYNC)&&(O_FSYNC!=O_SYNC)
	if(val&O_FSYNC)
		printf(",synchronous writes");
#endif
	putchar('\n');
	return 0;
}
