/*************************************************************************
  > File Name: lseek.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月14日 星期四 19时44分49秒
 ************************************************************************/

#include<iostream>
#include"apue.h"
int main()
{
	if(lseek(STDIN_FILENO,0,SEEK_CUR)==-1)
		std::cout<<"can not seek"<<std::endl;
	else
		std::cout<<"seek ok"<<std::endl;
	return 0;
}
