/*************************************************************************
  > File Name: mktmp.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2018年01月08日 星期一 09时30分28秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<cstdlib>
#include<unistd.h>
#include<sys/types.h>
#include"apue.h"
#include<errno.h>
int log_to_stderr=1;
void make_temp(char* _template);
int main()
{
	char good_template[]="/tmp/dirXXXXXX";
	char* bad_template="/tmp/dirXXXXXX";
	printf("trying to create first temp file...\n");
	make_temp(good_template);
	printf("trying to create second temp file...\n");
	make_temp(bad_template);
	return 0;
}

void make_temp(char* _template)
{
	int fd;
	struct stat sbuf;
	if((fd = mkstemp(_template))<0)
		err_sys("can not create temp file");
	printf("temp name = %s\n",_template);
	close(fd);
	if(stat(_template,&sbuf)<0)
	{
		if(errno==ENOENT)
			printf("file does not exist\n");
		else
			err_sys("stat failed");
	}
	else
	{
		printf("file exists\n");
		unlink(_template);
	}
}
