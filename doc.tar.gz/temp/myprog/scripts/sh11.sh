#########################################################################
# File Name: sh11.sh
# Author: caoyuchao
# mail: cycbhbjxd@gmail.com
# Created Time: 2017年12月18日 星期一 11时52分23秒
#########################################################################
#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
network="10.14.126"
for sitenu in $(seq 1 100)
do
	ping -c l -w 1 ${network}.${sitenu} &> /dev/null && result=0 || result=1

	if [ "$result" == 0 ];then
		echo "Server ${network}.${sitenu} is UP."
	else
		echo "Server ${network}.${sitenu} is DOWN."
	fi
done
		
