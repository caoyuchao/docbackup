#########################################################################
# File Name: sh9.sh
# Author: caoyuchao
# mail: cycbhbjxd@gmail.com
# Created Time: 2017年12月18日 星期一 10时57分00秒
#########################################################################
#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
s=0
i=0
limit=100
if [ "$#" -gt 0 ];then
	limit=$1
fi

while [ "$i" != "$limit" ]
do
	i=$(($i+1))
	s=$(($s+$i))
done
echo "The result of '1+2+3...+100' is ==> $s"
