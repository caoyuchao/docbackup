#########################################################################
# File Name: sh13.sh
# Author: caoyuchao
# mail: cycbhbjxd@gmail.com
# Created Time: 2017年12月18日 星期一 12时14分51秒
#########################################################################
#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
read -p "Please input a number,i will count for 1+2+3...+your_input:" nu

s=0
for((i=1;i<=$nu;i++))
do
	s=$(($s+$i))
done
echo "The result of '1+2+3...+$nu' is ==>  $s"
