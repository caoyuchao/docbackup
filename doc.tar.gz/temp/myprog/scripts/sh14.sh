#########################################################################
# File Name: sh14.sh
# Author: caoyuchao
# mail: cycbhbjxd@gmail.com
# Created Time: 2017年12月28日 星期四 19时18分48秒
#########################################################################
#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
function arraydblr
{
	local origarray
	local newarray
	local elements
	local i

	origarray=($(echo "$@"))
	newarray=($(echo "$@"))
	elements=$[ $# -1 ]
	for(( i=0; i <= $elements; i++ ))
	{
		newarray[$i]=$[ ${origarray[$i]} * 2 ]
	}
	echo ${newarray[*]}

}

myarray=(1 2 3 4 5)
echo "The original array is: ${myarray[*]}"
arg1=`echo ${myarray[*]}`
result=($(arraydblr $arg1))
echo "The new array is : ${result[*]}"
