#########################################################################
# File Name: sh4.sh
# Author: caoyuchao
# mail: cycbhbjxd@gmail.com
# Created Time: 2017年12月17日 星期日 20时32分36秒
#########################################################################
#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
echo -e "You SHOULD input 2 numbers,I will cross them!"
read -p "first number: " firstnu
read -p "second number: " secnu
total=$(($firstnu*$secnu))
echo -e "The result of $firstnu x $ secnu is ==> $total"
