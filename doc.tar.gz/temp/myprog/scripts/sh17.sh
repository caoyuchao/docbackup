#########################################################################
# File Name: sh17.sh
# Author: caoyuchao
# mail: cycbhbjxd@gmail.com
# Created Time: 2017年12月28日 星期四 20时33分28秒
#########################################################################
#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
temp=`mktemp -t temp.XXXXXX`
temp2=`mktemp -t temp.XXXXXX`

function diskspace
{
	df -k > $temp
	zenity --text-info --title "Disk space" --filename=$temp --width 750 --height 400
}

function whoseon
{
	who > $temp
	zenity --text-info --title "Logged in users" --filename=$temp --width 500 --height 300
}

function memusage
{
	cat /proc/meminfo > $temp
	zenity --text-info --title "Memory usage" --filename=$temp --width 400 --height 600
}

while [ 1 ]
do
	zenity --list --radiolist --title "Sys Admin Menu" --column "Select" \
		--column "Menu Item" FALSE "Display diskspace" FALSE "Display users" \
		FALSE "Display memory usage" FALSE "Exit" --width 600 --height 380 > $temp2

	if [ $? -eq 1 ]
	then
		break
	fi

	selection=`cat $temp2`
	case $selection in
		"Dispaly diskspace")
			diskspace ;;
		"Display users")
			whoseon ;;
		"Display memory usage")
			memusage ;;
		Exit)
			break ;;
		*)
			zenity --info "Sorry,invalid selection"
	esac
done
