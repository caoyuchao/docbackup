#########################################################################
# File Name: sh1.sh
# Author: caoyuchao
# mail: cycbhbjxd@gmail.com
# Created Time: 2017年12月17日 星期日 20时06分32秒
#########################################################################
#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
echo -e "Hello World! \a"
exit 0
