#########################################################################
# File Name: sh18.sh
# Author: caoyuchao
# mail: cycbhbjxd@gmail.com
# Created Time: 2017年12月29日 星期五 13时31分52秒
#########################################################################
#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
#count number of lines in your PATH
mypath=`echo $PATH | sed 's/:/ /g'`
count=0
for directory in $mypath
do
	check=`ls $directory`
	for item in $check
	do
		count=$[ $count + 1 ]
	done
	echo "$directory - $count"
	count=0
done
