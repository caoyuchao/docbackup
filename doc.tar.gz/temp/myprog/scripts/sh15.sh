#########################################################################
# File Name: sh15.sh
# Author: caoyuchao
# mail: cycbhbjxd@gmail.com
# Created Time: 2017年12月28日 星期四 19时25分04秒
#########################################################################
#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
function factorial
{
	if [ $1 -eq 1 ]
	then
		echo 1
	else
		local temp=$[ $1 - 1 ]
		local result=`factorial $temp`
		echo $[ $result * $1 ]
	fi
}

read -p "Enter value: " value
result=`factorial $value`
echo "The factorial of $value is : $result"
