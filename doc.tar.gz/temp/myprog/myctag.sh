sudo ctags -R --sort=yes --c++-kinds=+p --fields=+iaS --extra=+q --language-force=C++
