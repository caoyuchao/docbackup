/*************************************************************************
  > File Name: myprocess.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年11月25日 星期六 12时47分12秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<cstdlib>
#include<unistd.h>
#include<sys/types.h>
#include<signal.h>
#include<sys/wait.h>
#include<sstream>
int pid1;
int pid2;
void pleaseExit(int signalNum)
{
	kill(pid1,SIGUSR1);
	kill(pid2,SIGUSR1);
}

void timeout(int signalNum)
{
	kill(pid1,SIGUSR1);
	kill(pid2,SIGUSR1);
}

void child1killedbyparent(int signalNum)
{
	std::cout<<"child1 process was killed by its parent..."<<std::endl;
	exit(0);
}

void child2killedbyparent(int signalNum)
{
	std::cout<<"child2 process was killed by its parent..."<<std::endl;
	exit(0);
}

int main()
{
	//int pid1;
	//int pid2;
	int pipefd[2];
	const size_t bufsize=64;

	if(pipe(pipefd)<0)
	{
		std::cout<<"pipe create failure..."<<std::endl;
		exit(0);//exception 
	}
	signal(SIGINT,pleaseExit);

	if((pid1=fork())==0)
	{
		signal(SIGINT,SIG_IGN);
		signal(SIGUSR1,child1killedbyparent);
		size_t count=1;
		while(true)
		{
		
			std::ostringstream msg;
			msg<<"childProcess1 send message for "<<count<<" times";
			//std::cout<<msg.str()<<std::endl;
			if(write(pipefd[1],msg.str().c_str(),msg.str().size())==-1)
			{
				std::cout<<"write msg failure..."<<std::endl;
				exit(0);
			}
			count++;
			sleep(1);
		}
	}
	else if((pid2=fork())==0)
	{
		signal(SIGINT,SIG_IGN);
		signal(SIGUSR1,child2killedbyparent);
		char buf[bufsize];
		while(true)
		{
			if(read(pipefd[0],buf,bufsize)>0)
			{
				std::cout<<buf<<std::endl;
			}
			sleep(1);
		}
	}
	else
	{
		signal(SIGALRM,timeout);
		alarm(10);
		wait(&pid1);
		wait(&pid2);
		close(pipefd[1]);
		close(pipefd[0]);
		std::cout<<"parentProcess exit success..."<<std::endl;
	}
	return 0;
}
