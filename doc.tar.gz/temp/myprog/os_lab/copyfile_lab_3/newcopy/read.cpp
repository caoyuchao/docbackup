/*************************************************************************
  > File Name: read.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月19日 星期二 16时11分30秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<cstdlib>
#include<unistd.h>
#include<sys/types.h>
#include<sys/shm.h>
#include<sys/sem.h>
#include<sys/wait.h>
#include<sstream>
#include<sys/stat.h>
#include<fcntl.h>
#include"func.h"
#include<string.h>


int main(int argc,char* argv[])
{
	if(argc<5)
	{
		std::cout<<"need more arguments..."<<std::endl;
		exit(0);
	}
	
	int fd=open(argv[3],O_RDONLY,0600);
	if(fd==-1)
	{
		std::cout<<"can not open file "<<argv[3]<<std::endl;
		exit(0);
	}

	key_t key_buf=str2int(argv[1]);
	int key_sem=str2int(argv[2]);
	int limit=str2int(argv[4]);

	int shmidbuf=shmget(key_buf,limit*sizeof(block),IPC_CREAT|0600);
	block* sharedbuf=(block*)shmat(shmidbuf,NULL,0);
	
	int semid=semget(key_sem,2,IPC_CREAT|0666);
	size_t index=0;
	struct block b;	

	while(b.len=read(fd,b.buf,size))
	{
		P(semid,0);
		sharedbuf[index]=b;
		V(semid,1);
		index=(++index)%limit;
	}
	P(semid,0);
	sharedbuf[index]=b;
	V(semid,1);
	close(fd);
	std::cout<<"read successfully..."<<std::endl;
	return 0;
}


