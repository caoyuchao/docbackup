*************************************************************************
  > File Name: func.h
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月19日 星期二 17时58分16秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<cstdlib>
#include<unistd.h>
#include<sys/types.h>
#include<sys/shm.h>
#include<sys/sem.h>
#include<sys/wait.h>
#include<sstream>
#include<sys/stat.h>
#include<fcntl.h>

const int size=10;

struct block 
{
	char buf[size];
	int len;
};

void P(int semid,ushort index);

void V(int semid,ushort index);

int str2int(std::string str);

