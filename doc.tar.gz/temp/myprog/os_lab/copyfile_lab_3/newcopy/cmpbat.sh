#########################################################################
# File Name: ./cmpbat.sh
# Author: caoyuchao
# mail: cycbhbjxd@gmail.com
# Created Time: 2017年12月23日 星期六 10时54分36秒
#########################################################################
#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
./copy vim.png out.png > /dev/null
./copy copy out.copy > /dev/null
./copy copy.cpp out.cpp > /dev/null

cmp vim.png out.png
cmp copy out.copy
cmp copy.cpp out.cpp


