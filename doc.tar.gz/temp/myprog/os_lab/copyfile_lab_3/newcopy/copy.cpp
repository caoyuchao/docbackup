/*************************************************************************
  > File Name: copy.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月19日 星期二 15时43分23秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<cstdlib>
#include<unistd.h>
#include<sys/types.h>
#include<sys/shm.h>
#include<sys/sem.h>
#include<sys/wait.h>
#include<sstream>
#include<sys/stat.h>
#include<fcntl.h>
#include"func.h"
union semnu
{
	int val;
	struct semid_ds* buf;
	ushort* array;
};

size_t limit=100;
std::string readfilename="in.txt";
std::string writefilename="out.txt";

int main(int argc,char* argv[])
{
	if(argc>1)
	{
		readfilename=argv[1];
		if(argc>2)
		{
			writefilename=argv[2];
		}
	}
	struct stat statbuff;
	if(stat(readfilename.c_str(),&statbuff)<0)
	{
		std::cout<<"check filename"<<std::endl;
		exit(0);
	}
	unsigned long filesize=statbuff.st_size;
	key_t key_buf=key_t(8888);
	int shmidbuf=shmget(key_buf,limit*sizeof(block),IPC_CREAT|0666);
	
	key_t key_sem=key_t(7777);
	int semid=semget(key_sem,2,IPC_CREAT|0666);
	
	union semnu arg;
	arg.val=limit;
	semctl(semid,0,SETVAL,arg);

	arg.val=0;
	semctl(semid,1,SETVAL,arg);

	std::stringstream ss;
	std::string keybufStr;
	std::string keysemStr;
	std::string limitStr;

	ss<<key_buf;
	ss>>keybufStr;

	ss.clear();
	ss<<key_sem;
	ss>>keysemStr;
	
	ss.clear();
	ss<<limit;
	ss>>limitStr;
	
	int pid1;
	int pid2;
	if((pid1=fork())==0)
	{
		execl("./read","./read",keybufStr.c_str(),keysemStr.c_str(),readfilename.c_str(),limitStr.c_str(),NULL);
	}
	else if((pid2=fork())==0)
	{
		execl("./write","./write",keybufStr.c_str(),keysemStr.c_str(),writefilename.c_str(),limitStr.c_str(),NULL);
	}
	else
	{
		wait(&pid1);
		wait(&pid2);
		semctl(semid,0,IPC_RMID,arg);
		shmctl(shmidbuf,IPC_RMID,NULL);
		std::cout<<"copy successfully..."<<std::endl;
	}
	return 0;
}
