/*************************************************************************
  > File Name: func.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年12月19日 星期二 18时00分42秒
 ************************************************************************/

#include"func.h"
void P(int semid,ushort index)
{
	sembuf sem{index,-1,0};//P操作
	semop(semid,&sem,1);
	return;
}

void V(int semid,ushort index)
{
	sembuf sem{index,1,0};//V操作
	semop(semid,&sem,1);
	return;
}

int str2int(std::string str)
{
	std::stringstream ss;
	ss<<str;
	int value;
	ss>>value;
	return value;
}
