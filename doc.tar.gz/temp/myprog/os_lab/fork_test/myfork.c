/*************************************************************************
  > File Name: myfork.c
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年11月25日 星期六 08时56分29秒
 ************************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
int main()
{
	int p1;
	while((p1=fork())==-1);
	if(p1==0)
	{
		printf("this is child process\n");
	}
	else
	{
		printf("this is parent process\n");
	}
	return 0;
}
