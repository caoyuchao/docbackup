/*************************************************************************
  > File Name: mysignal.c
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年11月25日 星期六 09时36分18秒
 ************************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<signal.h>
#include<unistd.h>
#include<sys/types.h>
void my_func(int sig_no)
{
	if(sig_no==SIGUSR1)
		printf("Receive SIGUSR1.\n");
	if(sig_no==SIGUSR2)
		printf("Receive SIGUSR2.\n");
	if(sig_no==SIGINT)
	{
		printf("Receive SIGINT.\n");
		exit(0);
	}
}


int main()
{
	if(signal(SIGUSR1,my_func)==SIG_ERR)
		printf("can't catch SIGUSR1.\n");
	if(signal(SIGUSR2,my_func)==SIG_ERR)
		printf("can't catch SIGUSR2.\n");
	if(signal(SIGINT,my_func)==SIG_ERR)
		printf("can't catch SIGINT.\n");
	kill(getpid(),SIGINT);
	while(1);
	return 0;
}
