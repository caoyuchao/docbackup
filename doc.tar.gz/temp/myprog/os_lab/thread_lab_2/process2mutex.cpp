/*************************************************************************
  > File Name: processMutex.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年11月28日 星期二 18时34分04秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<cstdlib>
#include<unistd.h>
#include<sys/types.h>
#include<sys/shm.h>
#include<sys/sem.h>
#include<sys/wait.h>
#include<sstream>
union semnu
{
	int val;
	struct semid_ds* buf;
	ushort* array;
};

int semid;
size_t limit=10;

void P(int semid,ushort index)
{
	sembuf sem{index,-1,0};//初始化参数，资源-1,P操作
	semop(semid,&sem,1);
	return;
}

void V(int semid,ushort index)
{
	sembuf sem{index,1,0};//初始化参数，资源+1,V操作
	semop(semid,&sem,1);
	return;
}


int main(int argc,char* argv[])
{
	if(argc>1)
	{
		std::stringstream ss;
		ss<<argv[1];
		ss>>limit;
	}

	int shmid=shmget(key_t(8888),sizeof(size_t),IPC_CREAT|0666);//no exception default
	size_t* shared=(size_t*)shmat(shmid,NULL,0);//将共享内存映射到可访问的地址
	*shared=0;

	semid=semget(ftok("/boot",0x66),2,IPC_CREAT|0666);//创建信号灯
	union semnu arg;
	arg.val=1;
	semctl(semid,0,SETVAL,arg);//信号灯初始值为1
	arg.val=0;
	semctl(semid,1,SETVAL,arg);

	int pid1;
	int pid2;
	if((pid1=fork())==0)//进程1,工作类似线程1
	{
		for(size_t i=0;i<limit;i++)
		{
			P(semid,0);
			*shared+=i;
			//sleep(1);//休眠验证是否成功互斥
			V(semid,1);
		}
		std::cout<<"child1 exit successfully..."<<std::endl;
		exit(0);//可有可无
	}
	else if((pid2=fork())==0)//进程2，工作类似线程2
	{
		for(size_t i=0;i<limit;i++)
		{
			P(semid,1);
			std::cout<<"sum is "<<*shared<<std::endl;//互斥失败将打印大量语句
			V(semid,0);
		}
		std::cout<<"child2 exit successfully..."<<std::endl;
		exit(0);
	}
	else
	{
		wait(&pid1);//等待进程1结束
		wait(&pid2);//等待进程2结束
		semctl(semid,1,IPC_RMID,arg);
		//semctl(semid,0,IPC_RMID,arg);//释放信号灯
		shmctl(shmid,IPC_RMID,NULL);//释放共享内存
		std::cout<<"parentProcess exit successfully..."<<std::endl;
	}
	return 0;
}
