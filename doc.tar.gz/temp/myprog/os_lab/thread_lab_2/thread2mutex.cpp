/*************************************************************************
  > File Name: mypthread.cpp
  > Author: caoyuchao
  > Mail: cycbhbjxd@gmail.com 
  > Created Time: 2017年11月28日 星期二 16时18分32秒
 ************************************************************************/

#include<iostream>
#include<string>
#include<cstdlib>
#include<unistd.h>
#include<sys/types.h>
#include<pthread.h>
//#include<linux/sem.h>
#include<sys/sem.h>
#include<sstream>
union semnu
{
	int val;
	struct semid_ds* buf;
	ushort* array;
};


int semid;
pthread_t p1;
pthread_t p2;
size_t limit=100;
size_t sum=0;

void P(int semid,short unsigned int index)
{
	sembuf sem{index,-1,0};//初始化参数，资源-1,P操作
	semop(semid,&sem,1);
	return;
}

void V(int semid,short unsigned int index)
{
	sembuf sem{index,1,0};//初始化参数，资源+1,V操作
	semop(semid,&sem,1);
	return;
}

void* subp1(void*)
{
	for(size_t i=0;i<limit;i++)
	{
		P(semid,0);
		sum+=i;
		//std::cout<<"calculating...."<<std::endl;
		//sleep(1);//休眠一秒钟，验证成功进行互斥
		V(semid,1);
	}
	std::cout<<"thread1 exit successfully..."<<std::endl;
}

void* subp2(void*)
{
	for(size_t i=0;i<limit;i++)
	{
		P(semid,1);
		std::cout<<"sum is "<<sum<<std::endl;//如果未成功互斥，则一秒钟时间将打印大量的语句
		V(semid,0);
	}
	std::cout<<"thread2 exit successfully..."<<std::endl;
}

int main(int argc,char* argv[])
{

	if(argc>1)
	{
		std::stringstream ss;
		ss<<argv[1];
		ss>>limit;
	}

	semid=semget(ftok("/boot",0x66),2,IPC_CREAT|0600);//创建2个信号灯
	union semnu arg;
	arg.val=1;
	semctl(semid,0,SETVAL,arg);//信号灯0初始值为1
	arg.val=0;
	semctl(semid,1,SETVAL,arg);//信号灯1初始值为0


	void* status1;
	void* status2;
	pthread_create(&p1,NULL,&subp1,NULL);//nullptr?
	pthread_create(&p2,NULL,&subp2,NULL);//创建线程

	pthread_join(p1,&status1);//等待线程p1结束
	pthread_join(p2,&status2);//等待线程p2结束
	
	semctl(semid,1,IPC_RMID,arg);
	//semctl(semid,0,IPC_RMID,arg);//删除信号灯
	std::cout<<"mainThread exit successfully..."<<std::endl;
	return 0;
}
