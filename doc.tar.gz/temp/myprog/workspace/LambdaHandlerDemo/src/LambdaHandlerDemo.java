import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class LambdaHandlerDemo extends Application {
	@Override
	public void start(Stage primaryStage) {
		HBox hBox = new HBox();
		hBox.setSpacing(10);
		hBox.setAlignment(Pos.CENTER);
		Button btNewButton = new Button("New");
		Button btOpenButton = new Button("Open");
		Button btSaveButton = new Button("Save");
		Button btPrintButton = new Button("Print");

		hBox.getChildren().addAll(btNewButton, btOpenButton, btSaveButton,
				btPrintButton);

	}
}
