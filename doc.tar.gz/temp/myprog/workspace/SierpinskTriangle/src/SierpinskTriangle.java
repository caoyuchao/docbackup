import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.stage.Stage;

public class SierpinskTriangle extends Application {
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		SierpinskTrianglePane trianglePane = new SierpinskTrianglePane();
		TextField tfOrder = new TextField();

		tfOrder.setOnAction(e -> {
			int order = Integer.parseInt(tfOrder.getText());
			order = order > 8 ? 8 : order;
			trianglePane.setOrder(order);
		});

		tfOrder.setPrefColumnCount(4);
		tfOrder.setAlignment(Pos.BOTTOM_RIGHT);

		HBox hBox = new HBox(10);
		hBox.getChildren().addAll(new Label("Enter an order: "), tfOrder);
		hBox.setAlignment(Pos.CENTER);

		BorderPane borderPane = new BorderPane();
		borderPane.setCenter(trianglePane);
		borderPane.setBottom(hBox);

		Scene scene = new Scene(borderPane, 200, 210);
		primaryStage.setTitle("SierpinskTriangle");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.widthProperty().addListener(ov -> trianglePane.paint());
		scene.heightProperty().addListener(ov -> trianglePane.paint());
	}

	public static void main(String[] args) {
		Application.launch(args);
	}

}

class SierpinskTrianglePane extends Pane {
	private int order = 0;

	public void setOrder(int order) {
		this.order = order;
		paint();
	}

	public SierpinskTrianglePane() {
		// TODO Auto-generated constructor stub
	}

	protected void paint() {
		Point2D point2d = new Point2D(getWidth() / 2, 10);
		Point2D point2d2 = new Point2D(10, getHeight() - 10);
		Point2D point2d3 = new Point2D(getWidth() - 10, getHeight() - 10);
		this.getChildren().clear();
		displayTriangles(order, point2d, point2d2, point2d3);
	}

	private void displayTriangles(int order, Point2D point2d, Point2D point2d2, Point2D point2d3) {
		if (order == 0) {
			Polygon triangle = new Polygon();
			triangle.getPoints().addAll(point2d.getX(), point2d.getY(), point2d2.getX(), point2d2.getY(),
					point2d3.getX(), point2d3.getY());
			triangle.setStroke(Color.BLACK);
			triangle.setFill(Color.WHITE);
			this.getChildren().add(triangle);
		} else {
			Point2D p12 = point2d.midpoint(point2d2);
			Point2D p23 = point2d2.midpoint(point2d3);
			Point2D p31 = point2d3.midpoint(point2d);

			displayTriangles(order - 1, point2d, p12, p31);
			displayTriangles(order - 1, p12, point2d2, p23);
			displayTriangles(order - 1, p31, p23, point2d3);
		}
	}

}
