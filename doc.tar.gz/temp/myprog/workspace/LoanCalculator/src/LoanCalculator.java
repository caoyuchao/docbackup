import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class LoanCalculator extends Application {
	private final TextField tfAnnualInterestRate = new TextField();
	private final TextField tfNumberOfYears = new TextField();
	private final TextField tfLoanAmount = new TextField();
	private final TextField tfMonthlyPayment = new TextField();
	private final TextField tfTotalPayment = new TextField();
	private final Button btCalculate = new Button("Calculate");

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		GridPane gridpane = new GridPane();
		gridpane.setHgap(5);
		gridpane.setVgap(5);
		gridpane.add(new Label("Annual Interest Rate"), 0, 0);
		gridpane.add(tfAnnualInterestRate, 1, 0);
		gridpane.add(new Label("Number Of Years"), 0, 1);
		gridpane.add(tfNumberOfYears, 1, 1);
		gridpane.add(new Label("Loan Amount"), 0, 2);
		gridpane.add(tfLoanAmount, 1, 2);
		gridpane.add(new Label("Monthly Payment"), 0, 3);
		gridpane.add(tfMonthlyPayment, 1, 3);
		gridpane.add(new Label("Total Payment"), 0, 4);
		gridpane.add(tfTotalPayment, 1, 4);
		gridpane.add(btCalculate, 1, 5);

		gridpane.setAlignment(Pos.CENTER);
		tfAnnualInterestRate.setAlignment(Pos.BOTTOM_RIGHT);
		tfLoanAmount.setAlignment(Pos.BOTTOM_RIGHT);
		tfMonthlyPayment.setAlignment(Pos.BOTTOM_RIGHT);
		tfNumberOfYears.setAlignment(Pos.BOTTOM_RIGHT);
		tfTotalPayment.setAlignment(Pos.BOTTOM_RIGHT);

		tfMonthlyPayment.setEditable(false);
		tfTotalPayment.setEditable(false);

		GridPane.setHalignment(btCalculate, HPos.RIGHT);
		// btCalculate.setOnAction(new EventHandler<ActionEvent>() {
		// @Override
		// public void handle(ActionEvent arg0) {
		// TODO Auto-generated method stub
		// calculateLoanPayment();
		// }
		// });
		btCalculate.setOnAction(e -> calculateLoanPayment());

		Scene scene = new Scene(gridpane, 400, 250);
		primaryStage.setTitle("LoanCalculator");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}

	private void calculateLoanPayment() {
		double interest = Double.parseDouble(tfAnnualInterestRate.getText());
		int year = Integer.parseInt(tfNumberOfYears.getText());
		double loanAmount = Double.parseDouble(tfLoanAmount.getText());
		Loan loan = new Loan(interest, year, loanAmount);
		tfMonthlyPayment.setText(String.format("$%.2f", loan.getMonthlyPayment()));
		tfTotalPayment.setText(String.format("$%.2f", loan.getTotalPayment()));

	}
}
