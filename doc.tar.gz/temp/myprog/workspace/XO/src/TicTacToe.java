import java.util.ArrayList;
import java.util.Stack;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class TicTacToe extends Application {

	public enum Chessman {
		BLACK, WHITE, NONE
	}

	public class ChessPos {
		public int x;
		public int y;

		public ChessPos(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}

	public class WinChessPos {
		public final ChessPos begin;
		public final ChessPos end;

		public WinChessPos(ChessPos begin, ChessPos end) {
			this.begin = begin;
			this.end = end;
		}
	}

	private final int size = 12;
	private final int LENGTH_TO_WIN = 5;
	private final int NEG_INFINITE = -123456789;
	private Chessman whoseTurn = Chessman.BLACK;
	private final Cell[][] cell = new Cell[size][size];
	private final Label lbStatus = new Label("BLACK's turn to play");
	private final BorderPane borderPane = new BorderPane();
	private final Stack<ChessPos> chessBoardStatus = new Stack<>();
	private boolean isOver = false;

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		GridPane pane = new GridPane();
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				pane.add(cell[i][j] = new Cell(i, j), j, i);
			}
		}

		lbStatus.setFont(Font.font("Times new Roman", FontWeight.BOLD, FontPosture.REGULAR, 35));
		lbStatus.setMaxHeight(40);
		HBox hBox = new HBox();
		hBox.setAlignment(Pos.CENTER);

		Button unDo = getButton("Undo");
		unDo.setOnMouseClicked(e -> {
			if (!isOver && !chessBoardStatus.isEmpty()) {
				ChessPos chessPos = chessBoardStatus.pop();
				cell[chessPos.x][chessPos.y].getChildren().clear();
				cell[chessPos.x][chessPos.y].setChessman(Chessman.NONE);
				whoseTurn = nextTurn();
				lbStatus.setText(whoseTurn + "'s turn");
			}
		});
		Button restart = getButton("Restart");
		restart.setOnMouseClicked(e -> initialBoard());

		hBox.getChildren().addAll(unDo, restart);

		borderPane.setTop(hBox);
		borderPane.setCenter(pane);
		borderPane.setBottom(lbStatus);

		Scene scene = new Scene(borderPane, 450, 450);
		primaryStage.setTitle("TicTacToe");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	private void initialBoard() {
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				cell[i][j].getChildren().clear();
				cell[i][j].setChessman(Chessman.NONE);
			}
		}
		lbStatus.setText("BLACK's turn to play");
		lbStatus.setTextFill(Color.BLACK);
		whoseTurn = Chessman.BLACK;
		isOver = false;
		chessBoardStatus.clear();
		if (borderPane.getChildren().get(0) instanceof Line) {
			borderPane.getChildren().remove(0);
		}
	}

	private Button getButton(String text) {
		Button button = new Button(text);
		button.setPrefWidth(1000);
		button.setMaxHeight(40);
		button.setFont(Font.font("Times New Roman", FontWeight.BOLD, 25));
		return button;
	}

	public static void main(String[] args) {
		Application.launch(args);
	}

	private boolean isValid(ChessPos pos) {
		return pos.x >= 0 && pos.x < size && pos.y >= 0 && pos.y < size;
	}

	public boolean isFull() {
		return chessBoardStatus.size() == size * size;
	}

	public boolean isWon(Chessman chessman, ChessPos pos) {
		WinChessPos winChessPos = getWinChessPos(chessman, pos);
		if (winChessPos.begin.x != -1) {
			drawLine(winChessPos.begin, winChessPos.end);
			return true;
		} else

		{
			return false;
		}
	}

	private void drawLine(ChessPos begin, ChessPos end) {
		Line line = new Line();
		double xOffset = cell[0][0].widthProperty().divide(2).doubleValue();
		double yOffset = cell[0][0].heightProperty().divide(2).doubleValue();
		double buttonHeight = 50;
		double lbstatusHeight = lbStatus.heightProperty().doubleValue();
		line.startXProperty().bind(borderPane.widthProperty().divide(size).multiply(begin.y - 1).add(xOffset));
		line.startYProperty().bind(borderPane.heightProperty().subtract(buttonHeight + lbstatusHeight).divide(size)
				.multiply(begin.x - 1).add(yOffset + buttonHeight));
		line.endXProperty().bind(borderPane.widthProperty().divide(size).multiply(end.y - 1).add(xOffset));
		line.endYProperty().bind(borderPane.heightProperty().subtract(buttonHeight + lbstatusHeight).divide(size)
				.multiply(end.x - 1).add(yOffset + buttonHeight));
		line.setStroke(Color.RED);
		line.setStrokeWidth(10);
		borderPane.getChildren().add(0, line);
	}

	private WinChessPos getWinChessPos(Chessman chessman, ChessPos pos) {
		ChessPos posTemp = new ChessPos(-1, -1);
		ArrayList<ChessPos> arrayList = new ArrayList<>();
		// 检测某一列
		for (int i = pos.x - LENGTH_TO_WIN + 1; i < pos.x + LENGTH_TO_WIN; i++) {
			posTemp.x = i;
			posTemp.y = pos.y;
			if (isValid(posTemp)) {
				if (chessman == cell[posTemp.x][posTemp.y].getChessman()) {
					arrayList.add(new ChessPos(posTemp.x + 1, posTemp.y + 1));
				} else {
					arrayList.add(new ChessPos(NEG_INFINITE, NEG_INFINITE));
				}
			}
		}
		ChessPos result = maxSubArray(arrayList);

		if (result.y - result.x >= LENGTH_TO_WIN - 1) {
			return new WinChessPos(arrayList.get(result.x), arrayList.get(result.y));
		}
		arrayList.clear();
		// 检测某一行
		for (int j = pos.y - LENGTH_TO_WIN + 1; j < pos.y + LENGTH_TO_WIN; j++) {
			posTemp.x = pos.x;
			posTemp.y = j;
			if (isValid(posTemp)) {
				if (chessman == cell[posTemp.x][posTemp.y].getChessman()) {
					arrayList.add(new ChessPos(posTemp.x + 1, posTemp.y + 1));
				} else {
					arrayList.add(new ChessPos(NEG_INFINITE, NEG_INFINITE));
				}
			}
		}
		result = maxSubArray(arrayList);

		if (result.y - result.x >= LENGTH_TO_WIN - 1) {
			return new WinChessPos(arrayList.get(result.x), arrayList.get(result.y));
		}
		arrayList.clear();
		// 检测y轴逆时针45斜线
		for (int i = pos.x - LENGTH_TO_WIN + 1; i < pos.x + LENGTH_TO_WIN; i++) {
			posTemp.x = i;
			posTemp.y = pos.y - pos.x + i;
			if (isValid(posTemp)) {
				if (chessman == cell[posTemp.x][posTemp.y].getChessman()) {
					arrayList.add(new ChessPos(posTemp.x + 1, posTemp.y + 1));
				} else {
					arrayList.add(new ChessPos(NEG_INFINITE, NEG_INFINITE));
				}
			}
		}
		result = maxSubArray(arrayList);
		if (result.y - result.x >= LENGTH_TO_WIN - 1) {
			return new WinChessPos(arrayList.get(result.x), arrayList.get(result.y));
		}
		arrayList.clear();

		// 检测x轴逆时针45斜线
		for (int i = pos.x - LENGTH_TO_WIN + 1; i < pos.x + LENGTH_TO_WIN; i++) {
			posTemp.x = i;
			posTemp.y = pos.x + pos.y - i;
			if (isValid(posTemp)) {
				if (chessman == cell[posTemp.x][posTemp.y].getChessman()) {
					arrayList.add(new ChessPos(posTemp.x + 1, posTemp.y + 1));
				} else {
					arrayList.add(new ChessPos(NEG_INFINITE, NEG_INFINITE));
				}
			}
		}

		result = maxSubArray(arrayList);
		if (result.y - result.x >= LENGTH_TO_WIN - 1) {
			return new WinChessPos(arrayList.get(result.x), arrayList.get(result.y));
		}
		return new WinChessPos(new ChessPos(-1, -1), new ChessPos(-1, -1));
	}

	// 返回的ChessPos装载arraylist中的起点终点的下标
	private ChessPos maxSubArray(ArrayList<ChessPos> arrayList) {
		int maxSum = NEG_INFINITE;
		int endSumHere = 0;
		int startSumHere = 0;
		int begin = -1;
		int end = -1;
		int tempSum = 0;
		for (int i = 0; i < arrayList.size(); i++) {
			tempSum += arrayList.get(i).x;
			if (tempSum > maxSum) {
				maxSum = tempSum;
				begin = startSumHere;
				end = endSumHere;
			}
			endSumHere++;
			if (tempSum <= 0) {
				tempSum = 0;
				startSumHere = i + 1;
				endSumHere = startSumHere;
			}

		}
		return new ChessPos(begin, end);
	}

	public class Cell extends Pane {
		private Chessman chessman = Chessman.NONE;
		public final ChessPos chessPos;

		public Cell(int x, int y) {
			// TODO Auto-generated constructor stub
			chessPos = new ChessPos(x, y);
			setStyle("-fx-border-color: black");
			this.setPrefSize(2000, 2000);
			this.setOnMouseClicked(e -> handleMouseClicked());
		}

		public Chessman getChessman() {
			return chessman;
		}

		public void setChessman(Chessman chessman) {
			this.chessman = chessman;
			switch (chessman) {
			case BLACK:
				paintChessman(Color.BLACK);
				break;
			case WHITE:
				paintChessman(Color.WHITE);
				break;
			default:
				break;
			}
		}

		private void paintChessman(Color color) {
			Ellipse ellipse = new Ellipse(this.getWidth() / 2, this.getHeight() / 2, this.getWidth() / 2 - 10,
					this.getHeight() / 2 - 10);
			ellipse.centerXProperty().bind(this.widthProperty().divide(2));
			ellipse.centerYProperty().bind(this.heightProperty().divide(2));
			ellipse.radiusXProperty().bind(this.widthProperty().divide(2).subtract(10));
			ellipse.radiusYProperty().bind(this.heightProperty().divide(2).subtract(10));
			ellipse.setStroke(Color.BLACK);
			ellipse.setFill(color);
			getChildren().add(ellipse);
		}

		private void handleMouseClicked() {

			if (isOver || chessman != Chessman.NONE || whoseTurn == Chessman.NONE) {
				return;
			}

			setChessman(whoseTurn);// 下棋
			chessBoardStatus.add(chessPos);

			if (isWon(whoseTurn, chessPos)) {
				setOver(whoseTurn + " won! the game is over");
			} else if (isFull()) {
				setOver("Draw! The game is over");
			} else {
				whoseTurn = nextTurn();
				lbStatus.setText(whoseTurn + "'s turn");
			}
		}

	}

	private void setOver(String tip) {
		lbStatus.setText(tip);
		lbStatus.setTextFill(Color.RED);
		whoseTurn = Chessman.NONE;
		isOver = true;
	}

	private Chessman nextTurn() {
		return (whoseTurn == Chessman.BLACK) ? Chessman.WHITE : Chessman.BLACK;
	}
}
