import java.util.*;

class Point//公有类 点坐标的抽象
{
	public Point(double x,double y)
	{
		this.x = x;
		this.y = y;
	}
	public double X(){return x;}
	public double Y(){return y;}
	private double x;
	private double y;
}


public class AngleCalc 
{
	
	public static final double distance(Point x,Point y)
	{
		return Math.sqrt((x.X()-y.X())*(x.X()-y.X())+(x.Y()-y.Y())*(x.Y()-y.Y()));
	}
	
	public static void main(String[] args)
	{
		Scanner input= new Scanner(System.in);
		System.out.println("Enter three points: ");
		double x1 = input.nextDouble();
		double y1 = input.nextDouble();
		double x2 = input.nextDouble();
		double y2 = input.nextDouble();
		double x3 = input.nextDouble();
		double y3 = input.nextDouble();
		input.close();
		
		double a = distance(new Point(x2, y2), new Point(x3, y3));
		double b = distance(new Point(x1, y1), new Point(x3, y3));
		double c = distance(new Point(x1, y1), new Point(x2, y2));
		
		double A = Math.toDegrees(Math.acos((a*a-b*b-c*c)/(-2*b*c)));
		double B = Math.toDegrees(Math.acos((b*b-a*a-c*c)/(-2*a*c)));
		double C = Math.toDegrees(Math.acos((c*c-a*a-b*b)/(-2*a*b)));
		
		System.out.println("The three angles are "+
		Math.round(A*100)/100.0+" "+
		Math.round(B*100)/100.0+" "+
		Math.round(C*100)/100.0);
		
		
	}
}
