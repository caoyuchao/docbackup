import java.awt.geom.Line2D;
import java.util.Vector;


class Point
{
	private double x;
	private double y;
	public Point()
	{
		this(0,0);
	}
	
	Point(double x0,double y0)
	{
		x = x0;
		y = y0;
	}
	
	public double getX(){return x;}
	public double getY(){return y;}
	
	public double distance(Point p)
	{
		return Math.sqrt((x-p.x)*(x-p.x)+(y-p.y)*(y-p.y));
	}
	
	public double distance(double x,double y)
	{
		return distance(new Point(x,y));
	}
}

class Line//类似向量
{
	private Point p1;
	private Point p2;
	
	public Line()
	{
		this(new Point(0,0), new Point(1,0));//X轴
	}
	
	public Line(Point point1,Point point2)
	{
		p1 = point1;
		p2 = point2;
	}
	
	public boolean contains(Point p)
	{
		return !this.isIntersect(new Line(p1,p));
	}
	
	public Point getP1(){return p1;}
	public Point getP2(){return p2;}
	
	public boolean isIntersect(Line line)
	{
		return (p1.getY()-p2.getY())*(line.getP1().getX()-line.getP2().getX()) 
				!= (line.getP1().getY()-line.getP2().getY())*(p1.getX()-p2.getX());
	}
	
	public Point getIntersection(Line line) throws Exception
	{
		if(this.isIntersect(line))
		{
			double e = (p1.getY()-p2.getY())*p1.getX()-(p1.getX()-p2.getX())*p1.getY();
			double f = (line.getP1().getY()-line.getP2().getY())*line.getP1().getX()-
					(line.getP1().getX()-line.getP2().getX())*line.getP1().getY();
			double g = (line.getP1().getY()-line.getP2().getY())*(p1.getX()-p2.getX())-
					(p1.getY()-p2.getY())*(line.getP1().getX()-line.getP2().getX());
			double x1 = ((p1.getX()-p2.getX())*f-(line.getP1().getX()-line.getP2().getX())*e)/g;
			double y1 = ((p1.getY()-p2.getY())*f-(line.getP1().getY()-line.getP2().getY())*e)/g;
			return new Point(x1,y1);
		}
		else 
		{
			throw new Exception("no intersection...");
		}
	}

}

class vector2D//二维向量
{
	private double x;
	private double y;
	public double getX(){return x;}
	public double getY(){return y;}
	
	vector2D(Point p1,Point p2)
	{
		x = p2.getX()-p1.getX();
		y = p2.getY()-p1.getY();
	}
	
	vector2D(double x0,double y0)
	{
		x = x0;
		y = y0;
	}
	
	vector2D()
	{
		this(0, 0);
	}
	
	public double CrossProduct(vector2D vec)
	{
		return x*vec.getY()-y*vec.getX();
	}
	
	public boolean isPointAtSameSideOfLine(Point M,Point N,Point A,Point B)
	{
		vector2D AB = new vector2D(A,B);
		return AB.CrossProduct(new vector2D(A,M))*AB.CrossProduct(new vector2D(A,N))>=0;
	}
}

class Triangle2D
{
	private Point A;
	private Point B;
	private Point C;
	public Triangle2D() throws Exception
	{
		this(new Point(0,0), new Point(1,1), new Point(2,5));
	}
	
	public Triangle2D(Point point1,Point point2,Point point3) throws Exception
	{
		if(new Line(point1,point2).isIntersect(new Line(point1,point3)))
		{
			A = point1;
			B = point2;
			C = point3;
		}
		else
		{
			throw new Exception("not creat a triangle...");
		}
	
	}
	
	public double getArea()
	{
		return Math.abs(new vector2D(A,B).CrossProduct(new vector2D(B,C))/2.0);
		/*另一种面积的计算方式
		double dis12 = p1.distance(p2);
		double dis13 = p1.distance(p3);
		double dis23 = p2.distance(p3);
		double s = (dis12 + dis13 + dis23)/3;
		return Math.sqrt(s*(s-dis12)*(s-dis13)*(s-dis23));
		*/
	}
	
	public double getPerimeter()
	{
		return A.distance(B)+A.distance(C)+B.distance(C);
	}
	
	public boolean contains(Point p)
	{
		vector2D PA = new vector2D(p, A);
		vector2D PB = new vector2D(p, B);
		vector2D PC = new vector2D(p, C);
		double temp = PA.CrossProduct(PB);
		return temp*PB.CrossProduct(PC)>=0 && temp*PC.CrossProduct(PA)>=0;
	}
}

public class Triangle
{
	public static void main(String[] args)throws Exception
	{
		Triangle2D triangle2d = new Triangle2D(new Point(0, 0), new Point(2, 0), new Point(0, 2));
		if(triangle2d.contains(new Point(1,1)))
			System.out.println("contains (1,1)..");
		if(triangle2d.contains(new Point(1.1,1.1)))
			System.out.println("contains (1.1,1.1)");
		if(triangle2d.contains(new Point(0.9, 0.9)))
			System.out.println("contains (0.9,0.9)");
		
		System.out.println("Triangle area is " + triangle2d.getArea());
	}
}
