import java.util.Scanner;

public class Fib {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter an index for Fibonacci number: ");
		int index = input.nextInt();
		input.close();
		System.out.println("The Fibonacci number at index " + index + " is " + fibonacci(index));
	}

	public static long fibonacci(long index) {
		return fibonacci(index, 0, 1);
	}

	public static long fibonacci(long index, long result1, long result2) {
		if (index == 0) {
			return result1;
		} else {
			return fibonacci(index - 1, result2, result1 + result2);
		}
	}
}
