
public class Rational extends Number implements Comparable<Rational>
{
	private long numerator = 0;
	private long denominator = 1;
	
	public Rational()
	{
		this(0,1);
	}
	
	public Rational(long numerator, long denomiator)
	{
		long gcd = gcd(Math.abs(numerator),Math.abs(denomiator));
		this.numerator = ((denomiator > 0)?1:-1)*numerator/gcd;
		this.denominator = Math.abs(denomiator)/gcd;
	}
	
	private static long gcd(long x,long y)
	{
		if(x<y)return gcd(y, x);
		
		if(y==0)
		{
			return x;
		}
		else 
		{
			if((x&1)==0)
			{
				if((y&1)==0)return gcd(x>>1, y>>1)<<1;
				else return gcd(x>>1, y);
			}
			else
			{
				if((y&1)==0)return gcd(x, y>>1);
				else return gcd(y, x-y);
			}
		}
	}
	
	public long getNumerator(){return numerator;}
	public long getDenomiator(){return denominator;}
	
	public Rational add(Rational secondRational)
	{
		long n = numerator * secondRational.getDenomiator()
				+denominator*secondRational.getNumerator();
		long d = denominator * secondRational.getDenomiator();
		return new Rational(n,d);
	}
	
	public Rational subtract(Rational secondRational)
	{
		long n = numerator * secondRational.getDenomiator()
				- denominator * secondRational.getNumerator();
		long d = denominator * secondRational.getDenomiator();
		return new Rational(n,d);
	}
	
	public Rational multiply(Rational secondRational)
	{
		long n = numerator * secondRational.getNumerator();
		long d = denominator * secondRational.getDenomiator();
		return new Rational(n,d);
	}
	
	public Rational divide(Rational secondRational)
	{
		long n = numerator * secondRational.getDenomiator();
		long d = denominator * secondRational.getNumerator();
		return new Rational(n,d);
	}
	
	@Override
	public String toString()
	{
		return numerator == 1 ? numerator+"" : numerator+"/"+denominator;
	}
	
	@Override
	public boolean equals(Object other)
	{
		 return this.subtract((Rational)other).getNumerator() == 0;
	}
	
	@Override
	public int intValue(){return (int)doubleValue();}
	@Override
	public float floatValue(){return (float)doubleValue();}
	@Override
	public double doubleValue(){return numerator*1.0/denominator;}
	@Override
	public long longValue(){return (long)doubleValue();}
	
	@Override
	public int compareTo(Rational o)
	{
		if(this.subtract(o).getNumerator()>0)
			return 1;//直接返回会有截断
		else if(this.subtract(o).getNumerator() < 0)
			return -1;
		else
			return 0;
	}
}
