
public class TestCircleRectangle 
{
	public static void main(String[] args)
	{
		
	}
}
