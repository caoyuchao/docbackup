import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;


public class Transform
{
	public static void main(String[] args) throws Exception
	{
		if(args.length != 2)
		{
			System.out.println("Usage: java sourceFileName targetFileName");
			System.exit(1);
		}
		
		File sourceFile = new File(args[0]);
		if(!sourceFile.exists())
		{
			System.out.println("Source file "+ args[0]+" not exist");
			System.exit(1);
		}
		
		StringBuilder buffer = new StringBuilder();
		Scanner input = new Scanner(sourceFile);
		
		while(input.hasNext())
		{
			String s = input.nextLine();	
			String s1 = s.trim();
			if(!s1.isEmpty() && s1.charAt(0) == '{')
			{
				buffer.append(" {");
				if(s1.length()>1)
				{
					buffer.append("\n"+s.replace('{', ' '));
				}
			}
			else 
			{
				buffer.append("\n"+s);
			}
		}
		
		input.close();
		
		PrintWriter output = new PrintWriter(new File(args[1]));
		output.print(buffer.toString());
		output.close();
		
	}
}
