import java.util.*;
public class ReverseStr
{
	public static void main(String[] args)
	{
		Scanner inScanner = new Scanner(System.in);
		String string;
		String rString;
		while(true)
		{
			System.out.println("input a string,\"quit\" to quit: ");
			
			string = inScanner.nextLine();
			if(string.equalsIgnoreCase("quit"))
				break;
			System.out.println(string);
			rString = Reverse(string);
			System.out.println(rString);
			
			if(string.equals(rString))
				System.out.println("Yes");
			else
				System.out.println("No");
		}
		inScanner.close();
	}
	
	public static String Reverse(String str)
	{
		StringBuffer stringBuffer = new StringBuffer();
		for(int i=str.length()-1;i>=0;i--)
		{
			stringBuffer.append(str.charAt(i));
		}
		return stringBuffer.toString();
	}
}
